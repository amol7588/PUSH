import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
url:string='https://localhost:44304/api/'
  constructor(private httpClient:HttpClient) { }
  httpOptions:any
  getNotification():Observable<any>
  {
  return  this.httpClient.get(this.url+'push');
  }

  subscribe(subscription):any
  {
    this.httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'}),
      observe: 'events'
  };

return this.httpClient.post(this.url + 'push', subscription, this.httpOptions)
  }

  getForcaste():Observable<any>
  {
   return this.httpClient.get(this.url + 'WeatherForecasts')
  }

  getPublicKey():Observable<any>
  {
   return this.httpClient.get(this.url + 'publickey')
  }
}
