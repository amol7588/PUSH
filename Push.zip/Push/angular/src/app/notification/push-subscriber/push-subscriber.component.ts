import { Component, OnInit } from '@angular/core';
import { SwPush } from '../../../../node_modules/@angular/service-worker';
import { NotificationService } from '../notification.service';
import { HttpClient, HttpHeaders } from '../../../../node_modules/@angular/common/http';

@Component({
  selector: 'app-push-subscriber',
  templateUrl: './push-subscriber.component.html',
  styleUrls: ['./push-subscriber.component.css']
})
export class PushSubscriberComponent implements OnInit {

  private _subscription: PushSubscription;
  public operationName: string;
  baseUrl:string='http://localhost:44304/'
  private httpOptions: any;

  constructor(private swPush: SwPush,private notification:NotificationService,private httpClient:HttpClient) {
    
  
  }

  ngOnInit()
  {
  this.swPush.subscription.subscribe((subscription) => {
      this._subscription = subscription;
    console.log(this._subscription)
      this.operationName = (this._subscription === null) ? 'Subscribe' : 'Unsubscribe';
    });
  }

  operation() {
    console.log(this._subscription);
    (this._subscription === null) ? this.subscribe() : this.unsubscribe(this._subscription.endpoint);
  }

  private subscribe() {

    this.httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'}),
      observe: 'events'
  };

    // Retrieve public VAPID key from the server
    this.notification.getPublicKey().subscribe(P => {
      
      // Request subscription with the service worker
      this.swPush.requestSubscription({
        serverPublicKey: P.publicKey
      })
      // Distribute subscription to the server
      .then(subscription => this.notification.subscribe(subscription).subscribe(
        () => { },
        error => console.error(error)
      ))
      .catch(error => console.error(error));
    },
    error => console.error(error));
  }


  unsubscribe(endpoint) {
    this.swPush.unsubscribe()
    .then(() => this.httpClient.delete(this.baseUrl + 'api/PushSubscriptions/' + encodeURIComponent(endpoint)).subscribe(() => { },
      error => console.error(error)
    ))
    .catch(error => console.error(error));

   }


}
