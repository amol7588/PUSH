﻿using Lib.Net.Http.WebPush;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace pushAPI
{
  public interface IPushSubscriptionService
    {
        IEnumerable<PushSubscription> GetAll();

        void Insert(PushSubscription subscription);

        void Delete(string endpoint);


    }
}
