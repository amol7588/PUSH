﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Lib.Net.Http.WebPush;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace pushAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PushController : ControllerBase
    {
        IPushSubscriptionService pushSubscription;
        public PushController(IPushSubscriptionService _pushSubscription)
        {
            pushSubscription = _pushSubscription;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Hi");
        }

        [HttpPost("/{user}")]
        public void Post([FromBody] Lib.Net.Http.WebPush.PushSubscription subscription,string user)
        {
            pushSubscription.Insert(subscription);
        }

        [HttpDelete("{endpoint}")]
        public void Delete(string endpoint)
        {
            pushSubscription.Delete(endpoint);
        }


    }
}